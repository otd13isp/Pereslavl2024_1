use actix_web::{get, post, web, App, HttpResponse, HttpServer, Responder, Result};
use serde::Deserialize;
use std::fs;

// для кодировки используется base64
extern crate base64;
use base64::{engine::general_purpose, Engine as _};

// запуск Actix Web
#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
            .service(hello)
            .service(getchartr)
            .route("/", web::get().to(load_html))
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}

// функция для загрузки начальной страницы
async fn load_html() -> impl Responder {
    let contents = fs::read_to_string("public/html/plot.html")
        .expect("Should have been able to read the file");
    HttpResponse::Ok().body(contents)
}

// запрос GET
#[get("/hw")]
async fn hello() -> impl Responder {
    HttpResponse::Ok().body("Hello world!")
}

// сщздание структуры FormData
#[derive(Deserialize)]
struct FormData {
    info: String,
    version: String,
}

/// извлекаем данные формы с помощью serde
/// этот обработчик вызывается, только если тип контента x-www-form-urlencoded
/// содержимое запроса может быть десериализовано в структуру FormData
#[post("/getchartr")]
async fn getchartr(form: web::Form<FormData>) -> Result<String> {
    let params = [("a", &form.info), ("b", &form.version)];
    let client = reqwest::Client::new();
    let res = client
        .post("http://localhost:8000/plotly")
        .form(&params)
        .send()
        .expect("failed to get response")
        .text()
        .expect("failed to get payload");
    Ok(format!("{}", general_purpose::STANDARD_NO_PAD.encode(res)))
}
