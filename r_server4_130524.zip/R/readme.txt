# npm install pm2 -g

// test:
$ ./start.sh  

$ pm2 start startR.sh --interpreter none
