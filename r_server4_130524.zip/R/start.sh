pm2 start startR.sh --interpreter none
