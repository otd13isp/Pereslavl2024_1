#!/usr/bin/env Rscript

library(plumber)
pr("plot.R") %>%
  pr_run(port=8000, host="127.0.0.1")
# Setting the host option on a VM instance ensures the application can be accessed externally.
# (This may be only true for Linux users.)
